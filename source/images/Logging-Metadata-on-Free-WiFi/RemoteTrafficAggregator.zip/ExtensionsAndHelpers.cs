﻿// Nfdump and Syslog aggregator / normalisor
// Copyright (c) Murray Grant 2016

// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;

namespace RemoteTrafficAggregator
{
    public static class ExtensionsAndHelpers
    {
        public static bool Contains (this string s, string searchFor, StringComparison comparison)
        {
            if (s == null || String.IsNullOrEmpty(searchFor))
                return false;

            return s.IndexOf(searchFor, 0, comparison) != -1;
        }

        public static HashSet<T> ToHashSet<T>(this IEnumerable<T> collection)
        {
            return new HashSet<T>(collection);
        }
        public static HashSet<T> ToHashSet<T>(this IEnumerable<T> collection, IEqualityComparer<T> comparer)
        {
            return new HashSet<T>(collection, comparer);
        }

        public static int IndexOfBackwards(this string s, char ch, int startIdx)
        {
            if (s == null)
                throw new ArgumentNullException(nameof(s));
            if (startIdx < 0 || startIdx > s.Length)
                throw new ArgumentOutOfRangeException(nameof(startIdx), "StartIdx must be between zero and string length.");
            
            for (int i = startIdx; i >= 0; i--)
            {
                if (s[i] == ch) return i;
            }
            return -1;
        }

        public static void SendEmail(string subject, string body)
        {
            var toAddresses = System.Configuration.ConfigurationManager.AppSettings["emailNotificationAddresses"].Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
            if (!toAddresses.Any())
                return;
            var msg = new MailMessage();
            foreach (var addr in toAddresses)
                msg.To.Add(addr);
            msg.Subject = subject;
            msg.Body = body;
            try
            {
                new SmtpClient().Send(msg);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to send email: " + ex.ToString());
            }
        }
        public static int Exec(string executable, string arguments, int timeoutInMilliseconds = 20 * 1000)
        {
            var psi = new System.Diagnostics.ProcessStartInfo();
            psi.UseShellExecute = false;
            psi.FileName = executable;
            psi.Arguments = arguments;
            //psi.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            psi.RedirectStandardError = true;
            psi.RedirectStandardOutput = true;
            using (var p = new System.Diagnostics.Process()
            {
                StartInfo = psi,
            })
            {
                p.OutputDataReceived += (s, e) => Console.WriteLine(e.Data);
                p.ErrorDataReceived += (s, e) => Console.Error.WriteLine(e.Data);
                
                p.Start();
                var exitedBeforeTimeout = p.WaitForExit(timeoutInMilliseconds);
                if (!exitedBeforeTimeout)
                {
                    p.Kill();
                    return Int32.MaxValue;
                }
                return p.ExitCode;
            }

        }

        public static IEnumerable<T> MergeCollections<T, U>(IEnumerable<T> collection1, IEnumerable<T> collection2, Func<T, U> keySelector, IComparer<U> keyComparer)
        {
            var allCollections = new IEnumerable<T>[] { collection1, collection2 };
            var allEnumerators = new IEnumerator<T>[allCollections.Length];
            var enumeratorHasItems = new bool[allCollections.Length];
            int currentCollectionIdx = -1;

            // Pull from each collection and sort based on the key field.
            // As long as the key field is the same, we keep pulling from that collection.

            // Create enumerators for each collection.
            for (int i = 0; i < allCollections.Length; i++)
                allEnumerators[i] = allCollections[i].GetEnumerator();

            try
            {
                // Move to first element for each collection.
                for (int i = 0; i < allEnumerators.Length; i++)
                    enumeratorHasItems[i] = allEnumerators[i].MoveNext();

                // Select the collection to pull from by default (first non-empty collection).
                for (int i = 0; i < allEnumerators.Length; i++)
                {
                    if (enumeratorHasItems[i])
                    {
                        currentCollectionIdx = i;
                        break;
                    }
                }

                while (enumeratorHasItems.Any(x => x))
                {
                    // Find at least one valid enumerator.
                    while (!enumeratorHasItems[currentCollectionIdx])
                        currentCollectionIdx = (currentCollectionIdx + 1) % enumeratorHasItems.Length;

                    // Which enumerator should we pull from?
                    var currentKey = keySelector(allEnumerators[currentCollectionIdx].Current);
                    for (int i = 0; i < allEnumerators.Length; i++)
                    {
                        if (enumeratorHasItems[i] && currentCollectionIdx != i)
                        {
                            var compareToKey = keySelector(allEnumerators[i].Current);
                            var compareResult = keyComparer.Compare(currentKey, compareToKey);
                            if (compareResult <= 0)
                            {
                                // Current is first or equal, continue with current.
                            }
                            else if (compareResult > 0)
                            {
                                // This is before the current, so it should become the current.
                                currentCollectionIdx = i;
                                currentKey = keySelector(allEnumerators[currentCollectionIdx].Current);
                            }
                        }
                    }

                    // Yield.
                    yield return allEnumerators[currentCollectionIdx].Current;
                    enumeratorHasItems[currentCollectionIdx] = allEnumerators[currentCollectionIdx].MoveNext();
                }
            }
            finally
            {
                for (int i = 0; i < allEnumerators.Length; i++)
                    if (allEnumerators[i] != null)
                        allEnumerators[i].Dispose();
            }
        }
    }
}
