﻿using System;
using System.Globalization;

namespace MurrayGrant.CatalogQuerier
{
    /// <summary>
    /// Basics of a catalog item (ID, name and type only)
    /// </summary>
    public class CatalogItemLite
    {
        public CatalogItemLite(ItemInfo ii)
        {
            this.ID = ii.id;
            this.Name = ItemHelper.PathName(ii);
            this.Type = (ItemType)ii.itype;
        }

        public long ID { get; }
        public string Name { get; }

        public ItemType Type { get; }
        public bool IsFile => Type < ItemType.Archive;
        public bool IsFileOrArchive => Type <= ItemType.Archive;
        public bool IsContainer => Type >= ItemType.Archive;
        public bool IsNonArchiveContainer => Type > ItemType.Archive;

        public override string ToString()
            => $"{ID}: {Name} ({Type})";
    }

    /// <summary>
    /// File details of Catalog Item.
    /// </summary>
    public class CatalogItem
    {
        public CatalogItem(ItemAndFileInfo ii)
        {
            this.ii = new ItemInfo()
            {
                id = ii.id,
                name = ii.name,
                flags = ii.flags,
                itype = ii.itype,
            };
            this.fi = new FileInfo()
            {
                id_item = ii.id,
                name = ii.name,
                size = ii.size.GetValueOrDefault(0L),
                fileflags = ii.fileflags,
                date_create = ii.date_create,
                date_change = ii.date_change,
                md5 = ii.md5,
            };
        }

        readonly ItemInfo ii;
        readonly FileInfo fi;

        public long ID => ii.id;
        public string Name => ItemHelper.PathName(ii);
        public string Path;

        public ItemType Type => (ItemType)ii.itype;
        public bool IsFile => Type < ItemType.Archive;
        public bool IsFileOrArchive => Type <= ItemType.Archive;
        public bool IsContainer => Type >= ItemType.Archive;
        public bool IsNonArchiveContainer => Type > ItemType.Archive;

        public long Size => fi.size.GetValueOrDefault(0L);

        public DateTimeOffset Created => DateTime.Parse(fi.date_create, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal);
        public DateTimeOffset Modified => DateTime.Parse(fi.date_change, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal);

        public string Hash 
            => (fi.md5 ?? "").Length > 64 
                ? fi.md5.Substring(0, 64) 
                : fi.md5;

        public override string ToString()
            => $"{ID}: {Name} ({Type}) {Size / (1024.0 * 1024.0):N2}MB";

    }

    /// <summary>
    /// Details of a Volume Item (with a physical path)
    /// </summary>
    public class VolumeItem
    {
        public VolumeItem(ItemAndVolumeInfo ii)
        {
            this.ii = new ItemInfo()
            {
                id = ii.id,
                flags = ii.flags,
                itype = ii.itype,
                name = ii.name,
            };
            this.vi = new VolumeInfo()
            {
                id_item = ii.id,
                filesys = ii.filesys,
                volume_label = ii.volume_label,
                root_path = ii.root_path,
                vtype = ii.vtype,
                size_total = ii.size_total,
                size_free = ii.size_free,
                serial = ii.serial,
                disk_number = ii.disk_number,
                date_added = ii.date_added,
                date_updated = ii.date_updated,
            };
        }

        readonly ItemInfo ii;
        readonly VolumeInfo vi;

        public long ID => ii.id;
        public string Name => ItemHelper.PathName(ii);
        public string Path;
        public string FileSystem => vi.filesys;
        public string VolumeLabel => vi.volume_label;
        public string RootPath => vi.root_path;
    }

    public static class ItemHelper
    {
        public static string PathName(ItemInfo ii)
            => PathName(ii.itype, ii.name);

        public static string PathName(int itemType, string name)
            => itemType == (int)ItemType.NetworkDrive && !string.IsNullOrEmpty(name)
                ? name.Substring(0, name.IndexOf(' '))
                : name;
    }
}