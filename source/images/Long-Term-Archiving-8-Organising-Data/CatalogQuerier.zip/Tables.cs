﻿using System;

namespace MurrayGrant.CatalogQuerier
{
    public class Descent
    {
        public long id_item { get; set; }
        public long id_parent { get; set; }
    }


    public class ItemInfo
    {
        public long id { get; set; }
        public int flags { get; set; }
        public int itype { get; set; }
        public string name { get; set; }
    }

    public class FileInfo
    {
        public long id_item { get; set; }
        public string name { get; set; }
        public string date_change { get; set; }
        public string date_create { get; set; }
        public long? size { get; set; }
        public string fileflags { get; set; }
        public string md5 { get; set; }
    }

    public class ItemAndFileInfo
    {
        public long id { get; set; }
        public int flags { get; set; }
        public int itype { get; set; }
        public string name { get; set; }
        public string date_change { get; set; }
        public string date_create { get; set; }
        public long? size { get; set; }
        public string fileflags { get; set; }
        public string md5 { get; set; }
    }

    public class VolumeInfo
    {
        public long id_item { get; set; }
        public string filesys { get; set; }
        public string volume_label { get; set; }
        public string root_path { get; set; }
        public int vtype { get; set; }
        public long size_total { get; set; }
        public long size_free { get; set; }
        public long serial { get; set; }
        public int disk_number { get; set; }
        public string date_added { get; set; }
        public string date_updated { get; set; }
    }

    public class ItemAndVolumeInfo
    {
        public long id { get; set; }
        public int flags { get; set; }
        public int itype { get; set; }
        public string name { get; set; }

        public string filesys { get; set; }
        public string volume_label { get; set; }
        public string root_path { get; set; }
        public int vtype { get; set; }
        public long size_total { get; set; }
        public long size_free { get; set; }
        public long serial { get; set; }
        public int disk_number { get; set; }
        public string date_added { get; set; }
        public string date_updated { get; set; }
    }

    public class ItemInfoAndParent
    {
        public long id { get; set; }
        public int flags { get; set; }
        public int itype { get; set; }
        public string name { get; set; }
        public long id_parent { get; set; }
    }

    public enum ItemType
    {
        None = 0,

        File = 1,
        ImageWithExif = 2,
        Image = 5,
        Video = 6,

        Archive = 100,
        Folder = 200,

        CatalogRoot = 150,
        ContactsRoot = 151,
        TagsRoot = 152,
        TrashRoot = 153,
        LocationsRoot = 154,

        VirtualFolder = 160,

        FixedDrive = 172,
        BluRayDisk = 187,
        NetworkDrive = 190,
    }
}