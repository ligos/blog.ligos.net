﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MurrayGrant.ReEncodeRecordedTV
{
    public class AppConfig
    {
        public string TvFolder { get; set; }
        public string PathToHandbrake { get; set; }
        public string HandbrakeCommandOptions { get; set; }
        public double? PollingDelayMinutes { get; set; }
        public TimeSpan PollingDelayTimespan() => TimeSpan.FromMinutes(PollingDelayMinutes.GetValueOrDefault(15));
        public string[] ExtensionsToDelete { get; set; }
        public IEnumerable<string> ExtensionsToDelete_Safe() => ExtensionsToDelete ?? Enumerable.Empty<string>();
        public System.Diagnostics.ProcessPriorityClass? ProcessPriority { get; set; }
        public System.Diagnostics.ProcessPriorityClass ProcessPriority_Safe() => ProcessPriority.GetValueOrDefault(System.Diagnostics.ProcessPriorityClass.BelowNormal);
        public System.Diagnostics.ProcessPriorityClass? HandbrakePriority { get; set; }
        public System.Diagnostics.ProcessPriorityClass HandbreakePriority_Safe() => HandbrakePriority.GetValueOrDefault(System.Diagnostics.ProcessPriorityClass.Idle);
        public double? PostEncodeDelayMinutes { get; set; }
        public TimeSpan PostEncodeDelayTimespan() => TimeSpan.FromMinutes(PostEncodeDelayMinutes.GetValueOrDefault(1));
    }
}
