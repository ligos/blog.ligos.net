﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Threading;

using Microsoft.Extensions.Configuration;

namespace MurrayGrant.ReEncodeRecordedTV
{
    class Program
    {
        private static CancellationTokenSource CancelSignal = new CancellationTokenSource();

        public static void Main(string[] args)
        {
            LogLine("Murray Grant - ReEncodeRecordedTV");
            Console.CancelKeyPress += Console_CancelKeyPress;

            // Read config.
            var conf = new ConfigurationBuilder()
                        .SetBasePath(Path.Combine(AppContext.BaseDirectory))
                        .AddJsonFile("appsettings.json", optional: false)
                        .Build();
            var config = conf.GetSection("ReEncodeRecordedTV").Get<AppConfig>();

            Process.GetCurrentProcess().PriorityClass = config.ProcessPriority_Safe();

            // Begin polling loop.
            PollingLoop(config, CancelSignal.Token);

            LogLine("ReEncodeRecordedTV ending.");
        }

        private static void Console_CancelKeyPress(object sender, ConsoleCancelEventArgs e)
        {
            CancelSignal.Cancel();
            e.Cancel = true;        // Co-operative shutdown rather than immediate.
            LogLine("Received CTRL+C Cancel Signal.");
        }

        private static void PollingLoop(AppConfig conf, CancellationToken cancellationToken)
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                // For each recorded TV File (*.ts).
                foreach (var videoFilePath in Directory.EnumerateFiles(conf.TvFolder, "*.ts", SearchOption.AllDirectories))
                {
                    try
                    {
                        var videoFileName = Path.GetFileName(videoFilePath);

                        // Check if we can open the file read / write with an exclusive lock.
                        LogLineStart($"Checking if '{videoFileName}' can be re-encoded... ");
                        var (canOpen, maybeOpenError) = CanOpenFile(videoFilePath);
                        if (!canOpen)
                        {
                            // Can't open: skip the file (it's probably still being recorded).
                            LogLineEnd("Cannot open: " + maybeOpenError);
                            continue;
                        }
                        LogLineEnd("Yes.");

                        // Start by removing any potential MP4 (on the assumption the encoding failed part way).
                        var outputMp4Path = Path.ChangeExtension(videoFilePath, "mp4");
                        if (File.Exists(outputMp4Path))
                        {
                            LogLine($"Removing '{Path.GetFileName(outputMp4Path)}' before encoding.");
                            File.Delete(outputMp4Path);
                        }

                        // Invoke Handbrake on it.
                        LogLine($"Re-encoding '{videoFileName}' using HandbrakeCLI...");
                        var cmdAgs = $" -i \"{videoFilePath}\" -o \"{outputMp4Path}\" " + conf.HandbrakeCommandOptions;
                        var exitCode = Exec(conf.PathToHandbrake, cmdAgs, conf.HandbreakePriority_Safe());

                        if (exitCode == 0)
                        {
                            // Handbrake succeeded!
                            LogLine($"Re-encoding '{videoFileName}' succeeded!");

                            // Clean up original file, plus and extras.
                            File.Delete(videoFilePath);
                            foreach (var ext in conf.ExtensionsToDelete_Safe())
                            {
                                if (File.Exists(Path.ChangeExtension(videoFilePath, ext)))
                                    File.Delete(Path.ChangeExtension(videoFilePath, ext));
                            }

                            // Wait for a bit after a successful encode (to give the CPU a short break).
                            if (cancellationToken.IsCancellationRequested)
                                break;
                            LogLine($"Waiting for {conf.PostEncodeDelayTimespan().TotalMinutes:N1} minutes after successful encoding.");
                            cancellationToken.WaitHandle.WaitOne(conf.PollingDelayTimespan());
                        }
                        else
                        {
                            // Handbrake failed: delete the mp4 it (may have) created.
                            LogLine($"Re-encoding '{videoFileName}' failed, deleting MP4.");
                            if (File.Exists(outputMp4Path))
                                File.Delete(outputMp4Path);
                        }

                        if (cancellationToken.IsCancellationRequested)
                            break;

                    }
                    catch (Exception ex)
                    {
                        LogLine($"Unexpected failure processing '{videoFilePath}': {ex.GetType().Name} - {ex.Message}");
                        LogLine(ex.ToString());
                    }
                }

                if (cancellationToken.IsCancellationRequested)
                    break;
                
                // Pause.
                LogLine($"Waiting for {conf.PollingDelayTimespan().TotalMinutes:N1} minutes.");
                cancellationToken.WaitHandle.WaitOne(conf.PollingDelayTimespan());
            }

            if (cancellationToken.IsCancellationRequested)
            {
                LogLine("Responding to Cancel Signal.");
                return;
            }
        }


        private static (bool, string) CanOpenFile(string path)
        {
            FileStream fs = null;
            try
            {
                fs = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
                return (true, "");
            }
            catch (Exception ex)
            {
                return (false, ex.GetType().Name + " - " + ex.Message);
            }
            finally
            {
                if (fs != null)
                    fs.Dispose();
            }
        }

        private static int Exec(string executable, string commandLineArguments, ProcessPriorityClass priority)
        {
            // Run executable.
            // Configure the processes.
            var psi = new ProcessStartInfo(executable, commandLineArguments);
            // And start it!
            using (var p = Process.Start(psi))
            {
                // Start it!
                p.PriorityClass = priority;

                // Wait until it completes.
                p.WaitForExit();
                
                // Return the result code.
                var exitCode = p.ExitCode;
                return exitCode;
            }
        }

        private static void P_ErrorDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (e == null || e.Data == null)
                return;
            Console.Error.WriteLine(e.Data);
        }

        private static void P_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (e == null || e.Data == null)
                return;
            Console.WriteLine(e.Data);
        }

        private static void LogLine(string s)
        {
            LogLineStart(s);
            LogLineEnd("");
        }
        private static void LogLineStart(string s)
        {
            Console.Write(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff: ") + s);
        }
        private static void LogLinePart(string s)
        {
            Console.Write(s);
        }
        private static void LogLineEnd(string s)
        {
            Console.WriteLine(s);
        }
    }
}
