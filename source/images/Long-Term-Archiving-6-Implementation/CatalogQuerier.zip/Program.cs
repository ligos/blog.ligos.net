﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Dapper;

namespace MurrayGrant.CatalogQuerier
{
    class Program
    {
        readonly static char[] PathSeparators = new char[] { '/', '\\' };

        static CancellationTokenSource TokenSource = new CancellationTokenSource();
        static DateTime NextProgressUpdate = DateTime.MinValue;
        static Encoding Utf8WithoutBOM = new UTF8Encoding(false);

        static Microsoft.Data.Sqlite.SqliteConnection Connection;

        const int SuccessReturnCode = 0;
        const int ArgumentErrorReturnCode = 1;
        const int CancelledErrorReturnCode = 2;
        const int ErrorReturnCode = 32;

        static async Task<int> Main(string[] args)
        {
            Console.CancelKeyPress += Console_CancelKeyPress;

            if (args.Length <= 1)
            {
                ShowUsage();
                return ArgumentErrorReturnCode;
            }

            var dbPath = args[1];
            var connectionString = $"Data Source={dbPath};Mode=ReadOnly";
            using (Connection = new Microsoft.Data.Sqlite.SqliteConnection(connectionString))
            {
                ReportMessage($"Opening database '{Path.GetFileName(dbPath)}'...");
                await Connection.OpenAsync();
                ReportMessage($"Success! version {Connection.ServerVersion}.");

                if (args[0].Equals("dump", StringComparison.OrdinalIgnoreCase))
                {
                    return await DumpContents(args[2]);
                }
                else if (args[0].Equals("findmissing", StringComparison.OrdinalIgnoreCase))
                {
                    return await FindUnbackedUpFiles(args[2], args.Skip(3).ToList());
                }
                else
                {
                    ShowUsage();
                    return ArgumentErrorReturnCode;
                }
            }
        }

        private static void Console_CancelKeyPress(object sender, ConsoleCancelEventArgs e)
        {
            e.Cancel = true;
            TokenSource.Cancel();
        }

        static void ReportMessage(string message)
        {
            Console.WriteLine(message);
            NextProgressUpdate = DateTime.UtcNow.AddSeconds(1);
        }

        static void ReportProgressWithoutTotal(int itemCount)
        {
            if (DateTime.UtcNow < NextProgressUpdate)
                return;

            Console.WriteLine("[{0:N0} items]", itemCount);
            NextProgressUpdate = DateTime.UtcNow.AddSeconds(2);
        }

        static void ReportProgressWithTotal(int currentItem, int totalItems)
        {
            if (DateTime.UtcNow < NextProgressUpdate)
                return;

            if (totalItems == 0)
            {
                ReportProgressWithoutTotal(currentItem);
                return;
            }

            var ratio = (double)currentItem / (double)totalItems;
            ratio = ratio > 1.0 ? 1.0 : ratio;

            Console.WriteLine("[{0:P1} - {1:N0} of {2:N0} items]", ratio, currentItem, totalItems);
            NextProgressUpdate = DateTime.UtcNow.AddSeconds(2);
        }

        /// <summary>
        /// Prints the content of a path.
        /// </summary>
        static async Task<int> DumpContents(string path)
        {
            var id = await FindContainer(path);
            if (id <= 0)
            {
                Console.WriteLine($"Unable to find: '{path}'.");
                return ErrorReturnCode;
            }
            if (TokenSource.IsCancellationRequested) return CancelledErrorReturnCode;

            Console.WriteLine($"Path: {path}");
            var contents = await GetContents(id);
            if (TokenSource.IsCancellationRequested) return CancelledErrorReturnCode;

            foreach (var item in contents)
            {
                Console.WriteLine("  " + item);
            }
            var totalSize = contents.Sum(x => x.Size);
            Console.WriteLine($"Total: {contents.Count:N0} item(s), {totalSize / (1024.0 * 1024.0):N2}MB");
            Console.WriteLine();

            return SuccessReturnCode;
        }

        /// <summary>
        /// Finds new files which have not been backed up yet and writes to a file.
        /// </summary>
        static async Task<int> FindUnbackedUpFiles(string backupDiskPath, IReadOnlyCollection<string> liveDataPaths)
        {
            // Find ids of all paths.
            ReportMessage($"Initialising...");

            var backupDiskId = await FindContainer(backupDiskPath);
            if (backupDiskId <= 0)
            {
                Console.WriteLine($"Unable to find: '{backupDiskPath}'.");
                return ErrorReturnCode;
            }
            if (TokenSource.IsCancellationRequested) return CancelledErrorReturnCode;

            // Find id of path for backup disks.
            var liveData = new List<(string path, long id, CatalogItem item)>(liveDataPaths.Count);
            foreach (var liveDataPath in liveDataPaths)
            {
                var liveDataId = await FindContainer(liveDataPath);
                if (liveDataId <= 0)
                {
                    Console.WriteLine($"Unable to find: '{liveDataPath}'.");
                    return ErrorReturnCode;
                }
                var liveDataItem = await GetItem(liveDataId);
                liveData.Add((liveDataPath, liveDataId, liveDataItem));
                if (TokenSource.IsCancellationRequested) return CancelledErrorReturnCode;
            }

            // Create index of all backup files.
            var index = await CreateBackupIndex(backupDiskPath, backupDiskId);
            if (TokenSource.IsCancellationRequested) return CancelledErrorReturnCode;
            if (index == null) return ErrorReturnCode;

            foreach (var ld in liveData)
            {
                // Check for missing files.
                var missingFiles = await CheckForMissingFiles(ld.path, ld.id, index);
                if (TokenSource.IsCancellationRequested) return CancelledErrorReturnCode;

                // Write missing files to disk.
                await WriteMissingFiles(ld.path, ld.item, missingFiles);
                if (TokenSource.IsCancellationRequested) return CancelledErrorReturnCode;
            }

            return SuccessReturnCode;
        }

        static async Task<BackupIndex> CreateBackupIndex(string backupDiskPath, long backupDiskId)
        {
            // Recurse all files and create index.
            ReportMessage($"Building index of items in '{backupDiskPath}' (adding)...");
            var index = new BackupIndex();
            await RecurseDetails(backupDiskId, (item) => index.Add(item));
            if (TokenSource.IsCancellationRequested) return null;

            // Sort so binary search works.
            ReportMessage($"Building index of items in '{backupDiskPath}' (sorting)...");
            index.Sort();
            ReportMessage($"Index complete. {index.Count:N0} files on backup disks indexed.");

            return index;
        }

        static async Task<List<CatalogItem>> CheckForMissingFiles(string liveDataPath, long liveDataId, BackupIndex index)
        {
            // Scan for items that are missing.
            ReportMessage($"Scanning for unbacked up items '{liveDataPath}'...");
            var nonBackedUpItems = new List<CatalogItem>();
            await RecurseDetails(liveDataId, (item) =>
            {
                if (!index.Contains(item.Hash, item.Size))
                {
                    nonBackedUpItems.Add(item);
                }
            });
            return nonBackedUpItems;
        }

        static async Task WriteMissingFiles(string liveDataPath, CatalogItem liveDataItem, IReadOnlyCollection<CatalogItem> missingItems)
        {
            if (missingItems.Count == 0)
            {
                ReportMessage($"All files are backed up for '{liveDataPath}'!");
                return;
            }

            // Write list of unbacked up files to file.
            ReportMessage($"Writing list of unbacked up items for '{liveDataPath}'...");
            
            var outPath = liveDataItem.Name + ".txt";
            using (var stream = new FileStream(outPath, FileMode.Create, FileAccess.Write, FileShare.None))
            using (var writer = new StreamWriter(stream, Utf8WithoutBOM))
            {
                await writer.WriteLineAsync("ID\tName\tPath\tSize\tCreated\tModified\tSHA256");
                foreach (var i in missingItems)
                {
                    var path = await GetPathTo(i.ID);
                    await writer.WriteLineAsync($"{i.ID}\t{i.Name}\t{path}\t{i.Size}\t{i.Created}\t{i.Modified}\t{i.Hash}");
                }
                var totalSize = missingItems.Sum(x => x.Size);
                await writer.WriteLineAsync($"{missingItems.Count}\t\t\t{totalSize}\t\t\t");
            }
            ReportMessage($"{missingItems.Count:N0} files are not backed up. See '{outPath}' for details.");
        }

        static async Task<long> FindContainer(string path)
        {
            if (path == string.Empty)
            {
                return 1;
            }

            var pathParts = path.Split(PathSeparators);
            var containers = await GetContainers(1);
            var currentPartId = 0L;

            for (int i = 0; i < pathParts.Length; i++)
            {
                var part = pathParts[i];
                var isLast = pathParts.Length == i;

                var maybeItem = containers.FirstOrDefault(x => string.Equals(x.Name, part, StringComparison.CurrentCultureIgnoreCase));
                if (maybeItem == null)
                {
                    return 0;
                }

                currentPartId = maybeItem.ID;
                containers = await GetContainers(maybeItem.ID);
            }

            return currentPartId;
        }

        static Task<List<CatalogItemLite>> GetItems(long itemId)
            => GetItems(itemId, _ => true);

        static async Task<List<CatalogItemLite>> GetItems(long itemId, Func<ItemInfo, bool> predicate)
        {
            var query = $@"
SELECT id, itype, name
FROM w3_items
INNER JOIN w3_decent
	ON id = id_item
WHERE id_parent = {itemId}
";

            var result = await Connection.QueryAsync<ItemInfo>(query);
            return result
                .Where(predicate)
                .Select(x => new CatalogItemLite(x))
                .ToList();
        }

        static Task<List<CatalogItemLite>> GetFiles(long itemId)
            => GetItems(itemId, x => x.itype < (int)ItemType.Archive);

        static Task<List<CatalogItemLite>> GetContainers(long itemId)
            => GetItems(itemId, x => x.itype >= (int)ItemType.Archive);

        static async Task<CatalogItem> GetItem(long itemId)
        {
            var query = $@"
SELECT i.id, i.itype, i.name
	, fi.date_change, fi.date_create, fi.size, fi.fileflags, fi.md5, fi.crc32
FROM w3_items i
LEFT JOIN w3_fileInfo fi
	ON i.id = fi.id_item
WHERE i.id = {itemId}
";

            var result = await Connection.QueryFirstOrDefaultAsync<ItemAndFileInfo>(query);
            return new CatalogItem(result);
        }

        static async Task<List<CatalogItem>> GetContents(long itemId)
        {
            var query = $@"
SELECT i.id, i.itype, i.name
	, fi.date_change, fi.date_create, fi.size, fi.fileflags, fi.md5, fi.crc32
FROM w3_items i
INNER JOIN w3_decent d
	ON i.id = d.id_item
LEFT JOIN w3_fileInfo fi
	ON i.id = fi.id_item
WHERE d.id_parent = {itemId}
";
            var result = await Connection.QueryAsync<ItemAndFileInfo>(query);
            return result
                .Select(x => new CatalogItem(x))
                .ToList();
        }

        static async Task<string> GetPathTo(long itemId)
        {
            var result = "";

            do
            {
                var query = $@"
SELECT id, itype, name, id_parent
FROM w3_items
INNER JOIN w3_decent
	ON id = id_item
WHERE id = {itemId}
";
                var part = await Connection.QueryFirstOrDefaultAsync<ItemInfoAndParent>(query);
                result = ItemHelper.PathName(part.itype, part.name) + "/" + result;

                itemId = part.id_parent;
            } while (itemId > 1);

            return result.Trim('/');
        }

        static async Task RecurseDetails(long itemId, Action<CatalogItem> callback, int totalItems = 0)
        {
            var currentItem = 0;
            await RecurseDetailsInner(itemId, callback);

            async Task RecurseDetailsInner(long itemId, Action<CatalogItem> callback)
            {
                var items = await GetContents(itemId);
                if (TokenSource.IsCancellationRequested) return;
                var files = items.Where(x => x.IsFileOrArchive);
                foreach (var f in files)
                {
                    callback(f);
                    currentItem++;
                }

                if (TokenSource.IsCancellationRequested) return;
                var containers = items.Where(x => x.IsNonArchiveContainer);
                foreach (var c in containers)
                {
                    await RecurseDetailsInner(c.ID, callback);
                    if (TokenSource.IsCancellationRequested) return;
                    ReportProgressWithTotal(currentItem, totalItems);
                }
            }
        }

        static async Task<int> CountItems(long itemId)
        {
            var accumulator = 0;
            await CountItemsInner(itemId);
            return accumulator;

            async Task CountItemsInner(long itemId)
            {
                var items = await GetItems(itemId);
                if (TokenSource.IsCancellationRequested) return;
                var files = items.Where(x => x.IsFileOrArchive);
                accumulator = accumulator + files.Count();

                var containers = items.Where(x => x.IsNonArchiveContainer);
                foreach (var c in containers)
                {
                    await CountItemsInner(c.ID);
                    if (TokenSource.IsCancellationRequested) return;
                    ReportProgressWithoutTotal(accumulator);
                }
            }
        }

        static void ShowUsage()
        {
            Console.Write(@"CatalogQuerier <command> <arguments>
Commands:
  dump        <pathToW3catFile> <catalogPath>
  findmissing <pathToW3catFile> <catalogPathToBackups> <catalogPathToLiveData...>
");
        }
    }
}
