﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace MurrayGrant.CatalogQuerier
{
    public class BackupIndex
    {
        readonly List<IndexItemClass> Items;

        public BackupIndex()
            : this(16_384) { }
        public BackupIndex(int itemCount)
        {
            Items = new List<IndexItemClass>(itemCount);
        }

        public int Count => Items.Count;

        public void Add(CatalogItem item)
        {
            Items.Add(new IndexItemClass() { Hash = item.Hash, Length = item.Size });
        }

        public void Sort()
        {
            Items.Sort();
        }

        public bool Contains(string hash, long length)
        {
            var item = new IndexItemClass() { Hash = hash, Length = length };
            return Items.BinarySearch(item) >= 0;
        }

        sealed class IndexItemClass : IComparable<IndexItemClass>, IEquatable<IndexItemClass>
        {
            public string Hash;
            public long Length;

            public int CompareTo(IndexItemClass other)
            {
                var hashCompare = Hash.CompareTo(other.Hash);
                if (hashCompare != 0)
                    return hashCompare;
                return Length.CompareTo(other.Length);
            }

            public bool Equals(IndexItemClass other)
                => other.Hash == Hash
                && other.Length == Length;

            public override bool Equals(object obj)
                => obj is IndexItemClass x 
                && Equals(x);

            public override int GetHashCode()
                => Hash.GetHashCode() ^ Length.GetHashCode();
        }

        [StructLayout(LayoutKind.Sequential)]
        struct IndexItemStruct
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
            public byte[] Hash;
            public long Length;
        }
    }
}
