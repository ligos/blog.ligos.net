﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MurrayGrant.ManifestMaker
{
    public class CreateArguments
    {
        public string? Path { get; set; } 
    }

    public class VerifyArguments
    {
        public string? PathToManifestFile { get; set; }
        public string? PathToVerify { get; set; }
    }
}
