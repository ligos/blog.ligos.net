﻿using System;
using System.Buffers;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MurrayGrant.ManifestMaker
{
    class Program
    {
        static CancellationTokenSource TokenSource = new CancellationTokenSource();
        static DateTime NextProgressUpdate = DateTime.MinValue;
        static Encoding Utf8WithoutBOM = new UTF8Encoding(false);

        static int FileCount = 0;
        static long TotalBytes = 0L;
        static int CurrentCount = 0;
        static long CurrentBytes = 0L;

        static Task<int> Main(string[] args)
        {
            // Parse args
            Console.CancelKeyPress += Console_CancelKeyPress;

            if (args.Length == 0)
            {
                ShowUsage();
                return Task.FromResult(1);
            }

            if (args[0].Equals("create", StringComparison.OrdinalIgnoreCase))
            {
                var objArgs = new CreateArguments()
                {
                    Path = args[1]
                };
                return CreateManifest(objArgs);
            }
            else if (args[0].Equals("verify", StringComparison.OrdinalIgnoreCase))
            {
                var objArgs = new VerifyArguments()
                {
                    PathToVerify = args[1],
                    PathToManifestFile = args[2],
                };
                return VerifyManifest(objArgs);
            }
            else
            {
                ShowUsage();
                return Task.FromResult(1);
            }
        }

        private static void Console_CancelKeyPress(object sender, ConsoleCancelEventArgs e)
        {
            e.Cancel = true;
            TokenSource.Cancel();
        }

        static string ReadFromUser(string prompt, string defaultResponse = "")
        {
            var finalPrompt = prompt
                            + (string.IsNullOrEmpty(defaultResponse) ? "" : $" (enter for default '{defaultResponse}')")
                            + ": ";
            Console.Write(finalPrompt);
            var result = Console.ReadLine();
            result = (string.IsNullOrWhiteSpace(result) ? defaultResponse : result);
            return result;
        }

        static void ReportMessage(string message)
        {
            Console.WriteLine(message);
            NextProgressUpdate = DateTime.UtcNow.AddSeconds(1);
        }

        static void ReportProgress(int currentFile, int fileCount, long currentBytes, long totalBytes, string? filename)
        {
            if (DateTime.UtcNow < NextProgressUpdate)
                return;

            var filenameForProgress = string.IsNullOrEmpty(filename) ? "" : "; " + filename;
            if (currentFile == 0)
                Console.WriteLine("[{0:N0} files; {1:N1}MB{2}]", fileCount, totalBytes / 1024.0 / 1024.0, filenameForProgress);
            else
            {
                var ratio = (double)currentBytes / (double)totalBytes;
                ratio = ratio > 1.0 ? 1.0 : ratio;
                Console.WriteLine("[{0:P1} - {1:N0}/{2:N0} files; {3:N1}/{4:N1}MB{5}]", ratio, currentFile - 1, fileCount, currentBytes / 1024.0 / 1024.0, totalBytes / 1024.0 / 1024.0, filenameForProgress);
            }
            NextProgressUpdate = DateTime.UtcNow.AddSeconds(2);
        }

        static async Task<int> CreateManifest(CreateArguments args)
        {
            if (string.IsNullOrEmpty(args.Path))
                throw new ArgumentException("Path is required", nameof(args.Path));

            var defaultCode = Path.GetFileName(args.Path).ToUpperInvariant();
            var code = ReadFromUser("Enter disk code", defaultResponse: defaultCode).ToUpperInvariant();
            var description = ReadFromUser("Enter disk description");

            ReportMessage("Scanning files...");
            (FileCount, TotalBytes) = await GetTotals(args.Path);
            ReportMessage(string.Format("Total {0:N0} files, {1:N1}MB", FileCount, TotalBytes / 1024.0 / 1024.0));

            ReportMessage("Writing manifest...");
            var sw = Stopwatch.StartNew();

            var manifestPath = Path.Combine(args.Path, "!Manifest.txt");
            using (var hasher = SHA384.Create())
            using (var manifestStream = new FileStream(manifestPath, FileMode.Create, FileAccess.Write, FileShare.None))
            using (var writer = new StreamWriter(manifestStream, encoding: Utf8WithoutBOM, leaveOpen: true))
            {
                writer.NewLine = "\n";
                await writer.WriteAsync(ManifestHeader(code, description));

                var basePath = Path.GetFullPath(args.Path);
                await WalkDirectoryTree(args.Path, async fi =>
                {
                    CurrentCount++;
                    var relativePath = RelativePath(basePath, fi.FullName);
                    if (relativePath == "!Manifest.txt")
                        return;

                    using (var fileStream = fi.Open(FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        var hash = await ComputeHashAsync(hasher, fileStream, fi.Length);
                        var line = $"{relativePath}\t{fi.Length}\t{new DateTimeOffset(fi.CreationTimeUtc).LocalDateTime:O}\t{new DateTimeOffset(fi.LastWriteTimeUtc).LocalDateTime:O}\t{ToHexString(hash)}";
                        await writer.WriteLineAsync(line);
                    }

                    ReportProgress(CurrentCount, FileCount, CurrentBytes, TotalBytes, "");
                });
            }

            sw.Stop();
            ReportMessage(string.Format("Completed in {0:N1} seconds ({1:N1}MB/sec)", sw.Elapsed.TotalSeconds, CurrentBytes / 1024.0 / 1024.0 / sw.Elapsed.TotalSeconds));

            return 0;
        }

        static string ManifestHeader(string code, string description) =>
@$"FilePath	Size	Created	LastModified	Checksum	HeaderKey	HeaderValue
					Code	{code}
					Description	{description}
					Datestamp	{DateTimeOffset.Now:O}
					Checksum	sha384
".Replace("\r\n", "\n");

        static Task<int> VerifyManifest(VerifyArguments args)
        {
            throw new NotImplementedException();
        }

        static async Task<(int fileCount, long totalBytes)> GetTotals(string rootPath)
        {
            var basePath = Path.GetFullPath(rootPath);
            var fileCount = 0;
            var totalBytes = 0L;
            await WalkDirectoryTree(rootPath, fi =>
            {
                fileCount++;
                totalBytes += fi.Length;
                ReportProgress(0, fileCount, 0L, totalBytes, RelativePath(basePath, fi.DirectoryName));
                return Task.CompletedTask;
            });
            return (fileCount, totalBytes);
        }

        static async Task WalkDirectoryTree(string rootPath, Func<FileInfo, Task> callback)
        {
            foreach (var path in Directory.EnumerateFiles(rootPath).OrderBy(x => x))
            {
                await callback(new FileInfo(path));
                if (TokenSource.IsCancellationRequested)
                    return;
            }

            foreach (var path in Directory.EnumerateDirectories(rootPath).OrderBy(x => x))
            {
                await WalkDirectoryTree(path, callback);
                if (TokenSource.IsCancellationRequested)
                    return;
            }
        }

        static string ToHexString(byte[] bytes)
        {
            var buf = new char[bytes.Length * 2];
            for (int i = 0; i < bytes.Length; i++)
            {
                var s = bytes[i].ToString("X2");
                buf[i * 2] = s[0];
                buf[(i * 2) + 1] = s[1];
            }
            return new string(buf).ToLowerInvariant();
        }


        static readonly ArrayPool<byte> HashBufferPool = ArrayPool<byte>.Create();
        static async Task<byte[]> ComputeHashAsync(HashAlgorithm hasher, FileStream s, long fileSize)
        {
            var filename = Path.GetFileName(s.Name);
            hasher.Initialize();
            
            var buffer = HashBufferPool.Rent(32 * 1024 * 1024);
            try
            {
                int bytesRead;
                do
                {
                    bytesRead = await s.ReadAsync(buffer, 0, buffer.Length);
                    if (bytesRead > 0)
                        hasher.TransformBlock(buffer, 0, bytesRead, null, 0);

                    CurrentBytes += bytesRead;
                    ReportProgress(CurrentCount, FileCount, CurrentBytes, TotalBytes, filename);
                    if (TokenSource.IsCancellationRequested)
                        return new byte[hasher.HashSize / 8];

                } while (bytesRead > 0);

                hasher.TransformFinalBlock(buffer, 0, 0);
            }
            finally
            {
                HashBufferPool.Return(buffer);
            }

            return hasher.Hash;
        }

        static string RelativePath(string basePath, string fullPath)
            => string.Equals(basePath, fullPath, StringComparison.OrdinalIgnoreCase) ? basePath
             : fullPath.Substring(basePath.Length + 1);


        static void ShowUsage()
        {
            Console.Write(@"ManifestMaker <command> <arguments>
Commands:
  create <path>
  verify <pathToFiles> <pathToManifestFile>
");
        }
    }
}
